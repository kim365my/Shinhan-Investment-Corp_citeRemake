$(".header").load("../module/header.html");
$(".footer").load("../module/footer.html");